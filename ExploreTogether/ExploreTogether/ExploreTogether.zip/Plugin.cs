﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace ExploreAsOne
{
    //[BepInProcess("valheim.exe")]
    [BepInPlugin("com.rolopogo.plugins.exploretogether","ExploreTogether","1.0.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }
        public static BepInEx.Logging.ManualLogSource logger => Instance.Logger;
        public static BepInEx.Configuration.ConfigFile config => Instance.Config;

        void Awake()
        {
            Instance = this;
            Settings.Init();
            Harmony.CreateAndPatchAll(typeof(ExploreAsOne), "com.rolopogo.plugins.exploretogether");
        }
    }
}
