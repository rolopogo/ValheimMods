﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ExploreAsOne
{
    class ScenePrinter : MonoBehaviour
    {
        Scene activeScene;

        void Awake()
        {
            SceneManager.activeSceneChanged += (from, to) => activeScene = to;
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.F4))
            {
                PrintScene();
            }
        }

        void PrintScene()
        {
            string s = string.Empty;
            foreach (var go in activeScene.GetRootGameObjects())
            {
                s += PrintChildren(go.transform);
            }
            Plugin.logger.LogInfo(s);
        }

        string PrintChildren(Transform parent, int depth = 0)
        {
            string s = string.Empty;
            foreach (Transform t in parent)
            {
                for (int i = 0; i < depth; i++)
                {
                    s += " ";
                }
                s += t.name;
                s+= "(" + string.Join(", ", t.GetComponents<Component>().Select(x => x.GetType().ToString())) + ")";
                s += PrintChildren(t, depth + 1);
            }
            return s;
        }
    }
}
