﻿using BepInEx.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExploreAsOne
{
    static class Settings
    {
        public static ConfigEntry<bool> OthersRevealMap { get; private set; }
        public static ConfigEntry<bool> SharePinsWithOtherPlayers { get; private set; }
        public static ConfigEntry<bool> CoordsInMinimap { get; private set; }
        public static ConfigEntry<bool> CoordsInMap { get; private set; }
        public static ConfigEntry<bool> AutoShareLocation { get; private set; }
        public static ConfigEntry<bool> AddCoordsToPings { get; private set; }
        public static ConfigEntry<bool> PersistentPings { get; private set; }
        public static ConfigEntry<bool> PingWhereLooking { get; private set; }
        public static ConfigEntry<string> PingKey { get; private set; }

        public static void Init()
        {
            OthersRevealMap = Plugin.Instance.Config.Bind("Minimap",
                "OthersRevealMap",
                true,
                "Other players will reveal areas on the map near their position if they are sharing it");

            SharePinsWithOtherPlayers = Plugin.Instance.Config.Bind("Minimap",
                "SharePinsWithOtherPlayers",
                true,
                "Pins you create or edit will be sent to other players, and pins created by other players will be added to your map");

            CoordsInMinimap = Plugin.Instance.Config.Bind("Minimap",
                "CoordsInMinimap",
                true,
                "Display your players current coordinates in the small minimap");

            CoordsInMap = Plugin.Instance.Config.Bind("Minimap",
                "CoordsInMap",
                true,
                "Display the coordinates of your cursor in the map");

            AutoShareLocation = Plugin.Instance.Config.Bind("Minimap",
                "AutoShareLocation",
                true,
                "Enable sharing your position to other players by default");

            AddCoordsToPings = Plugin.Instance.Config.Bind("Minimap",
                "AddCoordsToPings",
                true,
                "Adds the coordinates of a ping to the message shown in chat in the form (x, y)");

            PingWhereLooking = Plugin.Instance.Config.Bind("General",
                "PingWhereLooking",
                true,
                "Create a ping where you are looking when you press <PingKey>");

            PingKey = Plugin.Instance.Config.Bind("General",
                "PingInputKey",
                "T",
                "The keybind to trigger a ping where you are looking");
        }
    }
}
