﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;
using ExploreAsOne.Utilities;
using UnityEngine.EventSystems;

namespace ExploreAsOne
{
    class ExploreAsOne
    {
        [HarmonyReversePatch]
        [HarmonyPatch(typeof(ZNet), "GetOtherPublicPlayers", new Type[] { typeof(List<ZNet.PlayerInfo>) })]
        public static void GetOtherPublicPlayers(object instance, List<ZNet.PlayerInfo> playerList) => throw new NotImplementedException();

        [HarmonyReversePatch]
        [HarmonyPatch(typeof(Minimap), "Explore", new Type[] { typeof(Vector3), typeof(float) })]
        public static void Explore(object instance, Vector3 p, float radius) => throw new NotImplementedException();

        [HarmonyReversePatch]
        [HarmonyPatch(typeof(Minimap), "Explore", new Type[] { typeof(int), typeof(int) })]
        public static bool Explore(object instance, int x, int y) => throw new NotImplementedException();

        [HarmonyReversePatch]
        [HarmonyPatch(typeof(Minimap), "ScreenToWorldPoint", new Type[] { typeof(Vector3) })]
        public static Vector3 ScreenToWorldPoint(object instance, Vector3 screenPos) => throw new NotImplementedException();

        [HarmonyPatch(typeof(ZNet), "Awake")]
        [HarmonyPostfix]
        private static void ZNet_Awake(ref ZNet __instance)
        {
            if (Settings.AutoShareLocation.Value)
            {
                __instance.SetPublicReferencePosition(true);
            }
        }

        [HarmonyPatch(typeof(Player), "Start")]
        [HarmonyPostfix]
        private static void Minimap_Start(Minimap __instance)
        {
            //var nview = Player.m_localPlayer.GetPrivateField<ZNetView>("m_nview");
            //nview.Register<Vector3, int, string, string>("PlayerAddedPin", RPC_PlayerAddedPin);
            //nview.Register<string>("ShareExploration", RPC_ShareExploration);
            ZRoutedRpc.instance.Register<string, string>("ShareExploration", RPC_ShareExploration);
            ZRoutedRpc.instance.Register<Vector3, int, string, string>("PlayerAddedPin", RPC_PlayerAddedPin);
        }

        [HarmonyPatch(typeof(Minimap), "UpdateExplore")]
        [HarmonyPrefix]
        private static bool Minimap_UpdateExplore(ref Minimap __instance, Player player, float ___m_exploreTimer, float ___m_exploreInterval, float ___m_exploreRadius, List<ZNet.PlayerInfo> ___m_tempPlayerInfo)
        {
            if (Settings.OthersRevealMap.Value)
            {
                if (___m_exploreTimer + Time.deltaTime > ___m_exploreInterval)
                {
                    ___m_tempPlayerInfo.Clear();
                    GetOtherPublicPlayers(ZNet.instance, ___m_tempPlayerInfo);

                    foreach (ZNet.PlayerInfo m_Player in ___m_tempPlayerInfo)
                    {
                        Explore(__instance, m_Player.m_position, ___m_exploreRadius);
                    }
                }
            }
            return true;
        }

        [HarmonyPatch(typeof(Minimap), "UpdateBiome")]
        [HarmonyPostfix]
        private static void Minimap_UpdateBiomePatch(Player player, Minimap __instance, Text ___m_biomeNameLarge, Text ___m_biomeNameSmall)
        {
            if (Settings.CoordsInMinimap.Value)
            {
                string coords = $"({Mathf.FloorToInt(player.transform.position.x)}, {Mathf.FloorToInt(player.transform.position.z)})";
                ___m_biomeNameSmall.text = ___m_biomeNameLarge.text.Split('\n')[0] + $"\n{coords}";
            }
            if (Settings.CoordsInMap.Value)
            {
                Vector3 cursor = ScreenToWorldPoint(__instance, UnityEngine.Input.mousePosition);
                string cursorCoords = $"({Mathf.FloorToInt(cursor.x)}, {Mathf.FloorToInt(cursor.z)})";
                ___m_biomeNameLarge.text = ___m_biomeNameSmall.text.Split('\n')[0] + $"\n{cursorCoords}";
            }
        }

        [HarmonyPatch(typeof(Minimap), "UpdateNameInput")]
        [HarmonyPrefix]
        private static bool Minimap_UpdateNameInput(Minimap __instance, Minimap.PinData ___m_namePin, bool ___m_wasFocused)
        {
            if (___m_namePin != null)
            {
                if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
                {
                    string text = __instance.m_nameInput.text;
                    text = text.Replace('$', ' ');
                    text = text.Replace('<', ' ');
                    text = text.Replace('>', ' ');

                    if (Player.m_localPlayer)
                    {
                        //var nview = Player.m_localPlayer.GetPrivateField<ZNetView>("m_nview");

                        //nview.InvokeRPC("PlayerAddedPin", ___m_namePin.m_pos, (int)___m_namePin.m_type, ___m_namePin.m_name);
                        ZRoutedRpc.instance.InvokeRoutedRPC("PlayerAddedPin", ___m_namePin.m_pos, (int)___m_namePin.m_type, ___m_namePin.m_name, Player.m_localPlayer.GetPlayerName());
                    }
                }
            }
            return true;
        }

        [HarmonyPatch(typeof(Minimap), "OnMapDblClick")]
        [HarmonyPostfix]
        private static void Minimap_OnMapDblClick(Minimap __instance, Minimap.PinType ___m_selectedType, Minimap.PinData ___m_namePin)
        {
            if (Settings.SharePinsWithOtherPlayers.Value)
            {
                if (Player.m_localPlayer)
                {
                    Vector3 pos = ScreenToWorldPoint(__instance, Input.mousePosition);
                    //var nview = Player.m_localPlayer.GetPrivateField<ZNetView>("m_nview");
                    //nview.InvokeRPC("PlayerAddedPin", pos, (int)___m_selectedType, ___m_namePin.m_name);
                    ZRoutedRpc.instance.InvokeRoutedRPC("PlayerAddedPin", pos, (int)___m_selectedType, ___m_namePin.m_name, Player.m_localPlayer.GetPlayerName());
                }
            }
        }

        private static void RPC_PlayerAddedPin(long sender, Vector3 pos, int type, string name, string player)
        {
            Plugin.logger.LogDebug(nameof(RPC_PlayerAddedPin));
            if (Settings.SharePinsWithOtherPlayers.Value)
            {
                var pins = Minimap.instance.GetPrivateField<Dictionary<Vector3, Minimap.PinData>>("m_locationPins");
                if (SimilarPinExists(pos, (Minimap.PinType)type, pins, out Minimap.PinData match))
                {
                    AddString(Chat.instance, $"{player} changed the name pin: \"{match.m_name}\" at ({Mathf.RoundToInt(pos.x)}, {Mathf.RoundToInt(pos.y)}) to {name}.");
                    match.m_name = name;
                }
                else
                {
                    AddString(Chat.instance, $"{player} added pin: \"{name}\" at ({Mathf.RoundToInt(pos.x)}, {Mathf.RoundToInt(pos.y)}).");
                }
                Minimap.instance.AddPin(pos, (Minimap.PinType)type, name, true, false);
            }
        }

        private static void RPC_ShareExploration(long sender, string exploredStr, string player)
        {
            if (Settings.OthersRevealMap.Value)
            {
                var textureSize = Minimap.instance.m_textureSize;
                for (int i = 0; i < textureSize; i++)
                {
                    for (int j = 0; j < textureSize; j++)
                    {
                        if (UnityEngine.Random.value < 0.2f)
                        Explore(Minimap.instance, i, j);
                    }
                }
                Minimap.instance.GetPrivateField<Texture2D>("m_fogTexture").Apply();
                //Minimap.instance.SetPrivateField("m_explored", expl, typeof(bool[]));
                AddString(Chat.instance, $"{player} shared their map with you.");
            }
        }

        private static bool SimilarPinExists(Vector3 pos, Minimap.PinType type, Dictionary<Vector3, Minimap.PinData> pins, out Minimap.PinData match)
        {
            foreach (Minimap.PinData pinData in pins.Values)
            {
                if (pinData.m_type == type && Utils.DistanceXZ(pos, pinData.m_pos) < 1f)
                {
                    match = pinData;
                    return true;
                }
            }
            match = null;
            return false;
        }

        [HarmonyPatch(typeof(Player), "Update")]
        [HarmonyPostfix]
        private static void Player_Update(Player __instance)
        {
            if (Player.m_localPlayer)
            {
                if (Settings.PingWhereLooking.Value)
                {
                    if (Enum.TryParse(Settings.PingKey.Value, out KeyCode key))
                    {
                        if (Input.GetKeyDown(key))
                        {
                            var dir = __instance.GetAimDir(Vector3.zero);
                            var ray = new Ray(GameCamera.instance.transform.position, GameCamera.instance.transform.forward);
                            Physics.Raycast(ray, out var hit, 500f);
                                 //__instance.GetPrivateField<int>("m_placeRayMask"));
                            Chat.instance.SendPing(hit.collider.transform.position);
                        }
                    }
                }
            }
        }

        [HarmonyPatch(typeof(Chat), "Awake")]
        [HarmonyPostfix]
        private static void Chat_Awake(Chat __instance)
        {
            AddString(__instance, "/shareMap - Share your current map exploration progress with other players");
            AddString(__instance, "/sharePins - Share your map pins with other players");
        }

        private static void AddString(Chat __instance, string text)
        {
            var buffer = __instance.GetPrivateField<List<string>>("m_chatBuffer");
            buffer.Add(text);
            while (buffer.Count > 15)
            {
                buffer.RemoveAt(0);
            }
            __instance.InvokeMethod("UpdateChat");

        }

        [HarmonyPatch(typeof(Chat), "InputText")]
        [HarmonyPrefix]
        private static bool Chat_InputText(Chat __instance, InputField ___m_input)
        {
            Plugin.logger.LogDebug(nameof(Chat_InputText));
            if (Player.m_localPlayer)
            {

                string text = ___m_input.text;
                if (text.ToLower() == "/sharemap")
                {
                    var mapExpl = Minimap.instance.GetPrivateField<bool[]>("m_explored");
                    string s = string.Empty;
                    foreach (var item in mapExpl)
                    {
                        if (s.Length < 1000)
                            s += item ? "1" : "0";
                    }
                    ZRoutedRpc.instance.InvokeRoutedRPC("ShareExploration", s, Player.m_localPlayer.GetPlayerName());
                    return false;
                }
                else if (text.ToLower() == "/sharepins")
                {
                    //get all pins, ignore pings
                    var pins = Minimap.instance.GetPrivateField<Dictionary<Vector3, Minimap.PinData>>("m_locationPins")
                        .Values.Where(x => x.m_type != Minimap.PinType.Ping)
                        .ToList();
                    foreach (var pin in pins)
                    {
                        ZRoutedRpc.instance.InvokeRoutedRPC("PlayerAddedPin", pin.m_pos, (int)pin.m_type, pin.m_name, Player.m_localPlayer.GetPlayerName());
                    }
                    return false;
                }
            }
            return true;
        }

        [HarmonyPatch(typeof(Chat), "SendPing")]
        [HarmonyPrefix]
        private static bool Chat_SendPingPatch(Vector3 position)
        {
            Player localPlayer = Player.m_localPlayer;
            if (localPlayer)
            {
                Vector3 vector = position;
                vector.y = localPlayer.transform.position.y;
                ZRoutedRpc.instance.InvokeRoutedRPC(ZRoutedRpc.Everybody, "ChatMessage", new object[]
                {
                vector,
                3,
                localPlayer.GetPlayerName(),
                $"Ping! ({Mathf.FloorToInt(vector.x)}, {Mathf.FloorToInt(vector.z)})"
                });
            }
            return false;
        }
    }
}
